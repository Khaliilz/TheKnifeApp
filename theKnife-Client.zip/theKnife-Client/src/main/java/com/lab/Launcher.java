package com.lab;

public class Launcher {
  
  public static void main(String[] args)
  {
    App.main(args);
  } 
}
