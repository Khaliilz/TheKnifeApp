package com.lab.controller.restaurateur;

import java.io.IOException;
import java.rmi.RemoteException;
import java.util.concurrent.CompletableFuture;
import javafx.application.Platform;
import java.util.List;

import com.lab.App;
import com.lab.controller.basic.PageController;
import com.lab.controller.basic.ToolbarController;
import com.lab.model.Session;
import com.lab.network.ServerConnection;
import com.lab.model.Restaurant;
import com.lab.utility.StringColor;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;

public class RestaurateurHomeController {
  
  @FXML private Text title;
  @FXML private VBox list;
  @FXML private StackPane contentArea;
  @FXML private ScrollPane listContainer;
  @FXML private Label emptyLabel;
  @FXML private VBox mainArea;

  private javafx.scene.Node detailsNode;
  private javafx.scene.Node newRestaurantNode;

  private static RestaurateurHomeController instance;

  @FXML
  public void initialize()
  {
    instance = this;

    PageController.showTitle(false);
    ToolbarController.showBackButton(false);
    ToolbarController.showLeftSide(false, false, true);

    title.setText("I tuoi ristoranti");
    fillRestaurants();
  }

  public static RestaurateurHomeController getInstance()
  {
    return instance;
  }

  public void setTitle(String t)
  {
    title.setText(t);
  }

  public void fillRestaurants()
  {
    list.getChildren().clear();

    if (Session.getCurrentUser() == null) return;
    int ownerId = Session.getCurrentUser().getId();

    CompletableFuture.supplyAsync(() -> {
      try{
        return ServerConnection.getServer().getRestaurantsByOwner(ownerId);
      } catch (RemoteException e) {
        e.printStackTrace();
        System.out.println("[" + StringColor.RED + "ERRORE" + StringColor.RESET + "] Richiesta dei tuoi ristoranti");
        return null;
      }
    }).thenAccept(restaurants -> {
      Platform.runLater(() -> {
        if(restaurants == null) {
          System.out.println("[" + StringColor.RED + "ERRORE" + StringColor.RESET + "] Richiesta dei tuoi ristoranti");
          emptyLabel.setText("Errore di connessione con il server");
          emptyLabel.setVisible(true);
          emptyLabel.setManaged(true);
        } else if(restaurants.isEmpty()) {
          emptyLabel.setText("Nessun ristorante presente al momento");
          emptyLabel.setVisible(true);
          emptyLabel.setManaged(true);
        } else {
          emptyLabel.setVisible(false);
          emptyLabel.setManaged(false);
          for(Restaurant r : restaurants) {
            try{
              FXMLLoader loader = new FXMLLoader(App.class.getResource("/com/lab/fxml/restaurateur/yourRestaurants.fxml"));
              HBox row = loader.load();

              YourRestaurantsController controller = loader.getController();
              controller.setRestaurantData(r);

              list.getChildren().add(row);
            }catch(IOException e) {
              System.out.println("[" + StringColor.RED + "ERRORE" + StringColor.RESET + "] Caricamento dei tuoi ristoranti");
              e.printStackTrace();
            }
          }
        }
      });
    });
  }

  public void openDetails(Restaurant r)
  {
    try{
      FXMLLoader loader = new FXMLLoader(App.class.getResource("/com/lab/fxml/restaurateur/detailsRestaurateur.fxml"));
      detailsNode = loader.load();

      setTitle(r.getName());
      
      DetailsRestaurateurController controller = loader.getController();
      controller.setRestaurant(r);

      mainArea.setVisible(false);
      contentArea.getChildren().add(detailsNode);
    }catch(IOException e) {
      System.out.println("[" + StringColor.RED + "ERRORE" + StringColor.RESET + "] Caricamento dettagli del tuo ristorante");
      e.printStackTrace();
    }
  }

  public void closeDetails()
  {
    if(detailsNode != null) {
      contentArea.getChildren().remove(detailsNode);
      detailsNode = null;
    }

    setTitle("I tuoi ristoranti");
    mainArea.setVisible(true);
    mainArea.requestFocus();

    fillRestaurants();
  }

  @FXML public void addClicked(ActionEvent event)
  {
    openNewRestaurant();
  }

  private void openNewRestaurant()
  {
    try {
      FXMLLoader loader = new FXMLLoader(App.class.getResource("/com/lab/fxml/restaurateur/newRestaurant.fxml"));
      newRestaurantNode = loader.load();

      setTitle("Nuovo Ristorante");

      mainArea.setVisible(false);
      contentArea.getChildren().add(newRestaurantNode);
    } catch(IOException ex) {
      System.out.println("[" + StringColor.RED + "ERRORE" + StringColor.RESET + "] Caricamento finestra form nuovo ristorante");
      ex.printStackTrace();
    }
  }

  public void closeNewRestaurant()
  {
    if(newRestaurantNode != null) {
      contentArea.getChildren().remove(newRestaurantNode);
      newRestaurantNode = null;
    }

    setTitle("I tuoi ristoranti");
    mainArea.setVisible(true);
    mainArea.requestFocus();

    fillRestaurants();
  }
}
