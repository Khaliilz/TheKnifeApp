package com.lab.controller.basic;

import com.lab.model.Session;
import com.lab.utility.StringColor;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

import java.util.concurrent.CompletableFuture;
import javafx.application.Platform;
import com.lab.network.ServerConnection;

public class ToolbarController {
  @FXML private StackPane toolbar;
  @FXML private Button exit_B;
  @FXML private Button minimize_B;
  @FXML private Button back_B;
  @FXML private Button signin_B;
  @FXML private Button signup_B;
  @FXML private Button signout_B;

  private static ToolbarController toolbarController;

  private double offsetX = 0;
  private double offsetY = 0;
  private String page = "/com/lab/fxml/basic/home.fxml";

  @FXML
  public void initialize()
  {

    toolbarController = this;

    toolbar.setOnMousePressed(event -> {
        offsetX = event.getSceneX();
        offsetY = event.getSceneY();
    });

    toolbar.setOnMouseDragged(event -> {
      Stage stage = (Stage) toolbar.getScene().getWindow();
      stage.setX(event.getScreenX() - offsetX);
      stage.setY(event.getScreenY() - offsetY);
    });
  }

  public static void showBackButton(boolean show)
  {
    if(toolbarController != null) {
      toolbarController.back_B.setVisible(show);
      toolbarController.back_B.setManaged(show);
    }
  }

  public static void setupBackButton(boolean show, String prevPage)
  {
    if(toolbarController != null) {
      toolbarController.back_B.setVisible(show);
      toolbarController.back_B.setManaged(show);
      toolbarController.page = prevPage;
    }
  }

  public static void showLeftSide(boolean signin, boolean signup, boolean signout)
  {
    if(toolbarController != null) {
      toolbarController.signin_B.setVisible(signin);
      toolbarController.signin_B.setManaged(signin);
      toolbarController.signup_B.setVisible(signup);
      toolbarController.signup_B.setManaged(signup);
      toolbarController.signout_B.setVisible(signout);
      toolbarController.signout_B.setManaged(signout);
    }
  }

  @FXML
  public void backClicked(ActionEvent event)
  {
    PageController.selectPage(page);
  }

  @FXML
  public void signinClicked(ActionEvent event)
  {
    PageController.selectPage("/com/lab/fxml/access/signin.fxml");
  }

  @FXML
  public void signupClicked(ActionEvent event)
  {;
    PageController.selectPage("/com/lab/fxml/access/signup.fxml");
  }

  @FXML
  public void signoutClicked(ActionEvent event)
  {
    if(Session.getCurrentUser() != null){
      final int userId = Session.getCurrentUser().getId();

      CompletableFuture.runAsync(() -> {
        try {
          ServerConnection.getServer().signout(userId);
        } catch(Exception e) { }
      });
    }

    Session.signOut();
    System.out.println("[" + StringColor.YELLOW + "SERVER" + StringColor.RESET + "] Uscito");
    PageController.selectPage("/com/lab/fxml/basic/home.fxml");
  }

  @FXML
  public void exitClicked(ActionEvent event)
  { 
    if(Session.getCurrentUser() != null){
      final int userId = Session.getCurrentUser().getId();

      CompletableFuture.runAsync(() -> {
        try {
          ServerConnection.getServer().signout(userId);
        } catch(Exception e) { }
      });
    }

    Session.signOut();
    System.out.println("[" + StringColor.YELLOW + "SERVER" + StringColor.RESET + "] Uscito");
    System.out.println("[" + StringColor.BLUE + "INFO" + StringColor.RESET + "] Applicazione chiusa");
    Platform.exit();
  }

  @FXML
  public void minimizeClicked(ActionEvent event)
  {
    System.out.println("[" + StringColor.BLUE + "INFO" + StringColor.RESET + "] Applicazione in finestra");
    Stage stage = (Stage) toolbar.getScene().getWindow();
    stage.setIconified(true);
  }
}
